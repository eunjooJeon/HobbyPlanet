function wrt_check_ok() {
   
   if(notice_form.n_title.value.length == 0){   
      alert("제목을 입력하세요.");
      notice_form.n_title.focus();
      return;
   } 
   
   if(notice_form.n_content.value.length == 0){
      alert("글 내용을 입력하세요.");
      notice_form.n_content.focus();
      return;
   }
   
   alert("글 작성 성공!");  
   document.notice_form.submit();
   // if문에 충족하지 않으면 form에 있는 action으로 submit 하겠다.
}

function edit_check_ok() {
   
   if(notice_form.n_title.value.length == 0){   
      alert("제목을 입력하세요.");
      notice_form.n_title.focus();
      return;
   } 
   
   if(notice_form.n_content.value.length == 0){
      alert("글 내용을 입력하세요.");
      notice_form.n_content.focus();
      return;
   }
   
   alert("글 수정 성공!");  
   document.notice_form.submit();
   // if문에 충족하지 않으면 form에 있는 action으로 submit 하겠다.
}