package com.javalec.final_hobbyplanet.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javalec.final_hobbyplanet.dao.JoinCommentDAO;
import com.javalec.final_hobbyplanet.dto.JoinCommentDTO;

@Service("JoinCommentService")
public class JoinCommentServiceImpl implements JoinCommentService{
   
	@Autowired
	private SqlSession sqlsession;

	@Override
	public void insertJoinComment(HashMap<String, String> param) {
		JoinCommentDAO dao = sqlsession.getMapper(JoinCommentDAO.class);
		dao.insertJoinComment(param);
	}

	@Override
	public ArrayList<JoinCommentDTO> listJoinComment(HashMap<String, String> param) {
		JoinCommentDAO dao = sqlsession.getMapper(JoinCommentDAO.class);
		ArrayList<JoinCommentDTO> dtos = dao.listJoinComment(param);
      
		return dtos;
	}

	@Override
	public void deleteJoinComment(HashMap<String, String> param) {
		JoinCommentDAO dao = sqlsession.getMapper(JoinCommentDAO.class);
		dao.deleteJoinComment(param);
	}
   
	@Override
	public void deleteComment(HashMap<String, String> param) {
		JoinCommentDAO dao = sqlsession.getMapper(JoinCommentDAO.class);
		dao.deleteComment(param);
	}

	@Override
	public void editJoinComment(HashMap<String, String> param) {
		JoinCommentDAO dao = sqlsession.getMapper(JoinCommentDAO.class);
		dao.editJoinComment(param);
	}
}