package com.javalec.final_hobbyplanet.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javalec.final_hobbyplanet.dao.MessageDAO;
import com.javalec.final_hobbyplanet.dto.MessageDTO;

//DAO���� sql���� ������
@Service("MessageService")
public class MessageServiceImpl implements MessageService {
	
	@Autowired
	private SqlSession sqlSession;

	@Override
	public ArrayList<MessageDTO> listMessage(HashMap<String, String> param) {
		MessageDAO dao = sqlSession.getMapper(MessageDAO.class);
		ArrayList<MessageDTO> list = dao.listMessage(param);

		return list;
	}
	
	@Override
	public MessageDTO viewMessage(HashMap<String, String> param) {
		MessageDAO dao = sqlSession.getMapper(MessageDAO.class);
		MessageDTO dto = dao.viewMessage(param);
		
		return dto;
	}

	@Override
	public void writeMessage(HashMap<String, String> param) {
		MessageDAO dao = sqlSession.getMapper(MessageDAO.class);
		dao.writeMessage(param);
	}

	@Override
	public void deleteMessage(HashMap<String, String> param) {
		MessageDAO dao = sqlSession.getMapper(MessageDAO.class);
		dao.deleteMessage(param);
	}
}