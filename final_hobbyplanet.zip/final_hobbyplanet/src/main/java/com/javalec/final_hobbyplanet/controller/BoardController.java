package com.javalec.final_hobbyplanet.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.javalec.final_hobbyplanet.dto.BoardCommentDTO;
import com.javalec.final_hobbyplanet.dto.BoardDTO;
import com.javalec.final_hobbyplanet.dto.PageMaker;
import com.javalec.final_hobbyplanet.dto.SearchCriteria;
import com.javalec.final_hobbyplanet.service.BoardCommentService;
import com.javalec.final_hobbyplanet.service.BoardService;

@Controller
public class BoardController {
	
	@Autowired
	private BoardService service;

	@Autowired
	private BoardCommentService commentService;
	
	@Autowired
	public HttpSession session;
	
   @RequestMapping("/board/listBoard")
   public String listBoard(SearchCriteria searchCriteria, Model model) {
	   ArrayList<BoardDTO> dtos = service.listBoard(searchCriteria);
	   model.addAttribute("list", dtos);
	   
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCriteria(searchCriteria);
		pageMaker.setTotal(service.countBoard(searchCriteria));
		model.addAttribute("pageMaker", pageMaker);
	   
	   return "board/listBoard";
   }


   @RequestMapping("/board/writeBoard")
   public String write(SearchCriteria searchCriteria, Model model) {
	   PageMaker pageMaker = new PageMaker();
	   pageMaker.setCriteria(searchCriteria);
	   pageMaker.setTotal(service.countBoard(searchCriteria));
	   model.addAttribute("pageMaker", pageMaker);
	   
	   
	   return "board/writeBoard";
   }

   @RequestMapping("/board/write_ok")
   public String writeBoard(@RequestParam HashMap<String, String> param) throws UnsupportedEncodingException {
	   service.insertBoard(param);
	   String encodedParam = URLEncoder.encode(param.get("keyword"), "UTF-8");
	   
	   return "redirect:listBoard?page="+param.get("page")+"&perPageNum="+param.get("perPageNum")+"&searchType="+param.get("searchType")+"&keyword="+encodedParam;
   }
   
   @RequestMapping("/board/showBoard")
   public String getBoard(@RequestParam HashMap<String, String> param, Model model, SearchCriteria searchCriteria) {
	   service.hitBoard(param);
	   BoardDTO dto = service.getBoard(param);
	   model.addAttribute("getBoard", dto);
	   
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCriteria(searchCriteria);
		pageMaker.setTotal(service.countBoard(searchCriteria));
		model.addAttribute("pageMaker", pageMaker);
	   
		ArrayList<BoardCommentDTO> dtoc = commentService.listBoardComment(param);
		model.addAttribute("listComment", dtoc);
	   
	   return "board/showBoard";
   }
   
   @RequestMapping("/board/editBoard")
   public String getEditBoard(@RequestParam HashMap<String, String> param, Model model, SearchCriteria searchCriteria) {
	   BoardDTO dto = service.getBoard(param);
	   model.addAttribute("getEditBoard", dto);
	   
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCriteria(searchCriteria);
		pageMaker.setTotal(service.countBoard(searchCriteria));
		model.addAttribute("pageMaker", pageMaker);
	   
	   return "board/editBoard";
   }
   
   @RequestMapping("/board/edit_ok")
   public String eidtBoard(@RequestParam HashMap<String, String> param) throws UnsupportedEncodingException {
	   service.editBoard(param);
	   String encodedParam = URLEncoder.encode(param.get("keyword"), "UTF-8");
	   
	   return "redirect:showBoard?b_idx="+param.get("b_idx")+"&page="+param.get("page")+"&perPageNum="+param.get("perPageNum")+"&searchType="+param.get("searchType")+"&keyword="+encodedParam;
   }
   
   @RequestMapping("/board/deleteBoard")
   public String pwdBoard(@RequestParam HashMap<String, String> param, Model model, SearchCriteria searchCriteria) {
	   BoardDTO dto = service.getBoard(param);
	   model.addAttribute("getDeleteBoard", dto);
	   
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCriteria(searchCriteria);
		pageMaker.setTotal(service.countBoard(searchCriteria));
		model.addAttribute("pageMaker", pageMaker);
	   
	   return "board/deleteBoard";
   }
   
   @RequestMapping("/board/delete_ok")
   public String deleteBoard(@RequestParam HashMap<String, String> param) throws UnsupportedEncodingException {

//	   commentService.deleteBoardComment(param);
	   service.deleteBoard(param);
	   String encodedParam = URLEncoder.encode(param.get("keyword"), "UTF-8");
		   
		   return "redirect:listBoard?&page="+param.get("page")+"&perPageNum="+param.get("perPageNum")+"&searchType="+param.get("searchType")+"&keyword="+encodedParam;

   }
   
// ��� �ۼ�
   @RequestMapping("/board/comment_ok")
   public String writeBoardComment(@RequestParam HashMap<String, String> param) throws UnsupportedEncodingException {
	   commentService.insertBoardComment(param);
	   String encodedParam = URLEncoder.encode(param.get("keyword"), "UTF-8");
	   
	   return "redirect:showBoard?b_idx="+param.get("b_idx")+"&page="+param.get("page")+"&perPageNum="+param.get("perPageNum")+"&searchType="+param.get("searchType")+"&keyword="+encodedParam;
   }

// ��� ����
   @RequestMapping("/board/modifyComment_ok")
   public String modifyCommentBoard(@RequestParam HashMap<String, String> param) throws UnsupportedEncodingException {
	   	commentService.editBoardComment(param);
	   	String encodedParam = URLEncoder.encode(param.get("keyword"), "UTF-8");
	   	
	   	return "redirect:showBoard?b_idx="+param.get("b_idx")+"&page="+param.get("page")+"&perPageNum="+param.get("perPageNum")+"&searchType="+param.get("searchType")+"&keyword="+encodedParam;
   }

// ��� ����
   @RequestMapping("/board/deleteComment_ok")
   public String deleteBoardComment(@RequestParam HashMap<String, String> param) throws UnsupportedEncodingException {
	   commentService.deleteComment(param);
	   String encodedParam = URLEncoder.encode(param.get("keyword"), "UTF-8");
	   
	   return "redirect:showBoard?b_idx="+param.get("b_idx")+"&page="+param.get("page")+"&perPageNum="+param.get("perPageNum")+"&searchType="+param.get("searchType")+"&keyword="+encodedParam;
   }
}