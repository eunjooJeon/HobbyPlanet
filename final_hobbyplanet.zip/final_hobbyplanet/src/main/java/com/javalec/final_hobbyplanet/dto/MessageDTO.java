package com.javalec.final_hobbyplanet.dto;

import java.sql.Timestamp;

//me_idx          NUMBER(6)       PRIMARY KEY,                            -- ���� ��ȣ
//me_sid          VARCHAR2(15)    REFERENCES USERTABLE(u_id),             -- ���� �߽���
//me_rid          VARCHAR2(15)    REFERENCES USERTABLE(u_id),             -- ���� ������
//me_title        VARCHAR2(80)    NOT NULL,                               -- ���� ����
//me_content      VARCHAR2(3000)  NOT NULL,                               -- ���� ����
//me_date         DATE            DEFAULT SYSDATE                         -- ���� �ۼ���

public class MessageDTO {
	private int me_idx;
	private String me_snick;
	private String me_rnick;
	private String me_title;
	private String me_content;
	private Timestamp me_date;
	
	public MessageDTO() {}

	public MessageDTO(int me_idx, String me_snick, String me_rnick, String me_title, String me_content, Timestamp me_date) {
		this.me_idx = me_idx;
		this.me_snick = me_snick;
		this.me_rnick = me_rnick;
		this.me_title = me_title;
		this.me_content = me_content;
		this.me_date = me_date;
	}

	public int getMe_idx() {
		return me_idx;
	}
	public void setMe_idx(int me_idx) {
		this.me_idx = me_idx;
	}
	public String getMe_snick() {
		return me_snick;
	}
	public void setMe_snick(String me_snick) {
		this.me_snick = me_snick;
	}
	public String getMe_rnick() {
		return me_rnick;
	}
	public void setMe_rnick(String me_rnick) {
		this.me_rnick = me_rnick;
	}
	public String getMe_content() {
		return me_content;
	}
	public void setMe_content(String me_content) {
		this.me_content = me_content;
	}
	public Timestamp getMe_date() {
		return me_date;
	}
	public void setMe_date(Timestamp me_date) {
		this.me_date = me_date;
	}
	public String getMe_title() {
		return me_title;
	}
	public void setMe_title(String me_title) {
		this.me_title = me_title;
	}
}