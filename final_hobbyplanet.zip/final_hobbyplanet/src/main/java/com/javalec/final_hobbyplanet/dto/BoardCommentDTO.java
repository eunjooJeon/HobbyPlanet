package com.javalec.final_hobbyplanet.dto;

import java.sql.Timestamp;

public class BoardCommentDTO {
	private int bc_idx;
	private int bc_bidx;
	private String bc_id;
	private String bc_nickname;
	private String bc_content;
	private Timestamp bc_date;
	
	public int getBc_idx() {
		return bc_idx;
	}
	public void setBc_idx(int bc_idx) {
		this.bc_idx = bc_idx;
	}
	public int getBc_bidx() {
		return bc_bidx;
	}
	public void setBc_bidx(int bc_bidx) {
		this.bc_bidx = bc_bidx;
	}
	public String getBc_id() {
		return bc_id;
	}
	public void setBc_id(String bc_id) {
		this.bc_id = bc_id;
	}
	public String getBc_nickname() {
		return bc_nickname;
	}
	public void setBc_nickname(String bc_nickname) {
		this.bc_nickname = bc_nickname;
	}
	public String getBc_content() {
		return bc_content;
	}
	public void setBc_content(String bc_content) {
		this.bc_content = bc_content;
	}
	public Timestamp getBc_date() {
		return bc_date;
	}
	public void setBc_date(Timestamp bc_date) {
		this.bc_date = bc_date;
	}
	
}
